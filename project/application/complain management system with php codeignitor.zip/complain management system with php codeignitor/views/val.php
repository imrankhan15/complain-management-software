<!DOCTYPE html>
<html> 
<body BGCOLOR='#888888'>
<div style="position:relative;top:40px;left:360px">
 <a href="http://localhost/project/index.php/comp/index">Make Complain</a> 
 <a href="http://localhost/project/index.php/login/index">Logout</a> 
</div>
Your request is being processed.
</body>

</html>