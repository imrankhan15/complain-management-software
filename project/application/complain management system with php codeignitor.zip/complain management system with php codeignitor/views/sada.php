<!DOCTYPE html>
<html> 
<body BGCOLOR='#888888'>
<div style="border:1px solid black;padding:15px;margin:20px;min-height:100px;background-color:#9999CC">
<p>
<center style="color:#180000;font-size:30px">
COMPLAIN MANAGEMENT SYSTEM FOR ENGINEERING SECTION,BUET

</center>
</p>

</div>


<br>

<br>
<br>
 <center>YOU HAVE TO LOG IN FIRST 
</center>

<br>
 <div style="position:relative;top:-70px;left:360px">

<table>
<form method="post" action="http://localhost/project/index.php/comp/index">
<tr><td>user type:</td>
<td>
<select name=page1usertype>
<option value=0 selected>Office
<option value=1>Hall
<option value=2>Personal

</select>
</td></tr>
<tr></tr>

<br>
<br>

<tr><td>user name:</td>
<td><input type="text" name=page1uname></td>
</tr>
<br>
<br>
<tr></tr>

<tr><td>password :</td>
<td><input type="password" name=page1pass ></td>
</tr>

<tr></tr>
<br>
<br>

<tr>
<td>
<input type="submit" name=page1submit value="log in" >
</td></tr>
</form>
</table>





</body>

</html>