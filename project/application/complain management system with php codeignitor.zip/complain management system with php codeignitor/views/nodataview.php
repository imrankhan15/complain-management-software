
<html> 
<body BGCOLOR='#888888'>
<div style="border:1px solid black;padding:15px;margin:20px;min-height:100px;background-color:#9999CC">
<p>
<center style="color:#180000;font-size:30px">
COMPLAIN MANAGEMENT SYSTEM FOR ENGINEERING SECTION,BUET

</center>
</p>

</div>


<br>

<br>
<br>
 <center>Sorry no data available
</center>

<br>
 <div style="position:relative;top:-70px;left:360px">
<form method="post" action="http://localhost/project/index.php/logout">
 <input type="submit" name=page4pro value="logout" >
</form>

<form method="post" action="http://localhost/project/index.php/comp">
 <input type="submit" name=page4pro value="back" >
</form>

</body>

</html>