


<html> 
<body BGCOLOR='#888888'>
<div style="border:1px solid black;padding:15px;margin:20px;min-height:100px;background-color:#9999CC">
<p>
<center style="color:#180000;font-size:30px">
COMPLAIN MANAGEMENT SYSTEM FOR ENGINEERING SECTION,BUET

</center>
</p>

</div>


<br>

<br>
<br>
 <center>YOU HAVE TO Select IN FIRST 
</center>

<br>
 <div style="position:relative;top:-70px;left:360px">

<table>
<form method="post" action="http://localhost/project/index.php/login/navigate">
<tr><td>user type:</td>
<td>
<select name=usertype>
<option value="">Select...</option>
<option value=Office selected>Office
<option value=Hall>Hall
<option value=Personal>Personal
<option value=0>Chief Engineer
<option value=1>Superintending Engineer
<option value=2>Executive Engineer
<option value=3>Sub-divisional Engineer
<option value=4>Sub-assistant Engineer
<option value=5>Supervisor
<option value=6>Technician

</select>
</td></tr>
<tr></tr>
<br>
<br>
<br>
<br>
<tr>
<td>
<input type="submit" name=page1submit value="log in" >
</td></tr>

</table>

</form>



</body>

</html>