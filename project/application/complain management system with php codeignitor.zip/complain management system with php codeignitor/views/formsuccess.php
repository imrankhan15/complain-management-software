<html>
<head>
<title>My Form</title>
</head>
<body>

<h3>Your form was successfully submitted!</h3>

<p><a href="http://localhost/project/index.php/form">Click Here</a></p>

</body>
</html>

